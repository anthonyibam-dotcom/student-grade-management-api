from typing import TYPE_CHECKING

from sqlalchemy import CheckConstraint, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base

if TYPE_CHECKING:
    from app.models.grade import Grade


class Course(Base):
    __tablename__ = "courses"
    __table_args__ = (CheckConstraint("credits >= 1 AND credits <= 5", name="ck_courses_credits_range"),)

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    code: Mapped[str] = mapped_column(String(20), unique=True, index=True, nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    credits: Mapped[int] = mapped_column(Integer, nullable=False)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)

    grades: Mapped[list["Grade"]] = relationship(
        "Grade", back_populates="course", cascade="all, delete-orphan"
    )
