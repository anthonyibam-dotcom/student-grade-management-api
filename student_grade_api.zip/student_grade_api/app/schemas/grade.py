from pydantic import BaseModel, ConfigDict, Field, field_validator


class GradeCreate(BaseModel):
    student_id: int = Field(gt=0)
    course_id: int = Field(gt=0)
    score: float = Field(ge=0, le=100)
    semester: str = Field(min_length=3, max_length=30)

    @field_validator("semester")
    @classmethod
    def normalize_semester(cls, value: str) -> str:
        value = " ".join(value.strip().split())
        if not value:
            raise ValueError("semester must not be blank")
        return value


class GradeUpdate(BaseModel):
    score: float = Field(ge=0, le=100)


class GradeResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    student_id: int
    course_id: int
    score: float
    letter_grade: str
    semester: str


class GPAResponse(BaseModel):
    student_id: int
    gpa: float = Field(ge=0, le=4)
    weighted_average: float = Field(ge=0, le=100)
    grade_count: int = Field(ge=0)


class CourseStatsResponse(BaseModel):
    course_id: int
    grade_count: int = Field(ge=0)
    mean_score: float | None = Field(default=None, ge=0, le=100)
    max_score: float | None = Field(default=None, ge=0, le=100)
    min_score: float | None = Field(default=None, ge=0, le=100)
    passing_rate: float | None = Field(default=None, ge=0, le=100)
